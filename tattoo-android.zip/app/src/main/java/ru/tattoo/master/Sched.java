package ru.tattoo.master;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

class Sched {
    private static PendingIntent pi(Context c, String id, String title, String body) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("t", title);
        i.putExtra("b", body);
        i.putExtra("id", id.hashCode() & 0xfffffff);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void set(Context c, String json) {
        SharedPreferences p = c.getSharedPreferences("tm", Context.MODE_PRIVATE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        try {
            JSONArray old = new JSONArray(p.getString("al", "[]"));
            for (int k = 0; k < old.length(); k++) {
                JSONObject o = old.getJSONObject(k);
                am.cancel(pi(c, o.getString("id"), "", ""));
            }
        } catch (Exception e) { }
        try {
            JSONArray a = new JSONArray(json);
            long now = System.currentTimeMillis();
            for (int k = 0; k < a.length(); k++) {
                JSONObject o = a.getJSONObject(k);
                long at = o.getLong("at");
                if (at > now) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at,
                        pi(c, o.getString("id"), o.getString("title"), o.getString("body")));
                }
            }
            p.edit().putString("al", json).apply();
        } catch (Exception e) { }
    }
}
