package ru.tattoo.master;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Notifier.show(c, i.getStringExtra("t"), i.getStringExtra("b"), i.getIntExtra("id", 1));
    }
}
