package ru.tattoo.master;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Sched.set(c, c.getSharedPreferences("tm", Context.MODE_PRIVATE).getString("al", "[]"));
    }
}
